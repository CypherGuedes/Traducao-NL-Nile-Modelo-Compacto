from __future__ import annotations

import copy
import re
from collections import Counter
from typing import Any, Dict, Iterable, List, Optional

from lark import Lark, Transformer, UnexpectedInput


class NileASTTransformer(Transformer):
    def NAME(self, token):
        return str(token)

    def STRING(self, token):
        return str(token)[1:-1]

    def endpoint_ref(self, items):
        return {"kind": "endpoint", "value": items[0]}

    def group_ref(self, items):
        return {"kind": "group", "value": items[0]}

    def traffic_ref(self, items):
        return {"kind": "traffic", "value": items[0]}

    def service_ref(self, items):
        return {"kind": "service", "value": items[0]}

    def protocol_ref(self, items):
        return {"kind": "protocol", "value": items[0]}

    def middlebox_ref(self, items):
        return {"kind": "middlebox", "value": items[0]}

    def route_scope(self, items):
        return {"from": items[0], "to": items[1]}

    def for_scope(self, items):
        return {"targets": list(items)}

    def scope_for(self, items):
        return {
            "type": "for",
            "from": None,
            "to": None,
            "targets": items[0]["targets"],
        }

    def scope_route(self, items):
        route = items[0]
        targets = items[1]["targets"] if len(items) > 1 else []
        return {
            "type": "route_for" if targets else "route",
            "from": route["from"],
            "to": route["to"],
            "targets": targets,
        }

    def add_op(self, items):
        return {"operator": "add", "items": list(items)}

    def allow_op(self, items):
        return {"operator": "allow", "items": list(items)}

    def block_op(self, items):
        return {"operator": "block", "items": list(items)}

    def quota_spec(self, items):
        return {
            "kind": "quota",
            "constraint": items[0],
            "value": items[1],
            "unit": items[2],
        }

    def bandwidth_spec(self, items):
        return {
            "kind": "bandwidth",
            "constraint": items[0],
            "value": items[1],
            "unit": items[2],
        }

    def bandwidth_empty(self, _items):
        return {"kind": "bandwidth"}

    def set_op(self, items):
        return {"operator": "set", "items": list(items)}

    def unset_op(self, items):
        return {"operator": "unset", "items": list(items)}

    def hour_ref(self, items):
        return {"kind": "hour", "value": items[0]}

    def start_clause(self, items):
        return items[0]

    def end_clause(self, items):
        return items[0]

    def interval(self, items):
        return {"start": items[0], "end": items[1]}

    def start(self, items):
        intent_id = items[0]
        scope = items[1]
        operations = []
        interval = None

        for item in items[2:]:
            if isinstance(item, dict) and "operator" in item:
                operations.append(item)
            elif isinstance(item, dict) and "start" in item and "end" in item:
                interval = item

        return {
            "intent_id": intent_id,
            "scope": scope,
            "operations": operations,
            "interval": interval,
        }


class NileValidator:
    QUOTA_CONSTRAINTS = {"any", "download", "upload"}
    BANDWIDTH_CONSTRAINTS = {"min", "max"}
    QUOTA_UNITS = {"gb", "gb/d", "gb/wk", "gb/mth", "mb/h"}
    BANDWIDTH_UNITS = {"mbps"}
    ALLOWED_TARGET_KINDS = {"endpoint", "group", "traffic"}
    ALLOWED_MATCH_KINDS = {"service", "traffic", "protocol"}
    ALLOWED_OPERATORS = {"add", "allow", "block", "set", "unset"}

    def __init__(self, grammar_text: str):
        if not isinstance(grammar_text, str) or not grammar_text.strip():
            raise ValueError("A gramática Nile não pode estar vazia.")

        self.grammar_text = grammar_text
        self.parser = Lark(
            grammar_text,
            parser="lalr",
            start="start",
            maybe_placeholders=False,
            propagate_positions=True,
        )
        self.transformer = NileASTTransformer()

    @staticmethod
    def _syntax_error(exc: UnexpectedInput, text: str) -> Dict[str, Any]:
        context = ""
        try:
            context = exc.get_context(text, span=45).strip()
        except Exception:
            context = ""

        expected = sorted(getattr(exc, "expected", []) or [])
        allowed = sorted(getattr(exc, "allowed", []) or [])

        return {
            "type": exc.__class__.__name__,
            "message": str(exc).splitlines()[0],
            "line": getattr(exc, "line", None),
            "column": getattr(exc, "column", None),
            "context": context,
            "expected": expected or allowed,
        }

    def parse(self, text: str) -> Dict[str, Any]:
        if not isinstance(text, str):
            return {
                "syntax_valid": False,
                "ast": None,
                "syntax_errors": [{
                    "type": "TypeError",
                    "message": "A expressão Nile deve ser uma string.",
                    "line": None,
                    "column": None,
                    "context": "",
                    "expected": [],
                }],
            }

        if not text.strip():
            return {
                "syntax_valid": False,
                "ast": None,
                "syntax_errors": [{
                    "type": "EmptyInput",
                    "message": "A expressão Nile está vazia.",
                    "line": 1,
                    "column": 1,
                    "context": "",
                    "expected": ["define"],
                }],
            }

        try:
            tree = self.parser.parse(text)
            ast = self.transformer.transform(tree)
            return {
                "syntax_valid": True,
                "ast": ast,
                "syntax_errors": [],
            }
        except UnexpectedInput as exc:
            return {
                "syntax_valid": False,
                "ast": None,
                "syntax_errors": [self._syntax_error(exc, text)],
            }
        except Exception as exc:
            return {
                "syntax_valid": False,
                "ast": None,
                "syntax_errors": [{
                    "type": exc.__class__.__name__,
                    "message": str(exc),
                    "line": None,
                    "column": None,
                    "context": "",
                    "expected": [],
                }],
            }

    @staticmethod
    def _is_nonempty_string(value: Any) -> bool:
        return isinstance(value, str) and bool(value.strip())

    @staticmethod
    def _is_number_string(value: Any) -> bool:
        return isinstance(value, str) and bool(re.fullmatch(r"(?:0|[1-9]\d*)(?:\.\d+)?", value.strip()))

    @staticmethod
    def _valid_hour(value: Any) -> bool:
        if not isinstance(value, str) or not re.fullmatch(r"\d{2}:\d{2}", value):
            return False
        hour, minute = map(int, value.split(":"))
        return 0 <= hour <= 23 and 0 <= minute <= 59

    @staticmethod
    def _add_error(errors: List[Dict[str, str]], code: str, path: str, message: str) -> None:
        errors.append({"code": code, "path": path, "message": message})

    def validate_ast(self, ast: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        errors: List[Dict[str, str]] = []

        if not isinstance(ast, dict):
            self._add_error(errors, "AST_MISSING", "$", "A AST não foi produzida.")
            return {"structural_valid": False, "structural_errors": errors}

        intent_id = ast.get("intent_id")
        if not self._is_nonempty_string(intent_id):
            self._add_error(errors, "INTENT_ID_EMPTY", "$.intent_id", "O identificador da intenção está vazio.")

        scope = ast.get("scope")
        if not isinstance(scope, dict):
            self._add_error(errors, "SCOPE_MISSING", "$.scope", "O escopo da intenção está ausente.")
        else:
            scope_type = scope.get("type")
            targets = scope.get("targets", [])
            origin = scope.get("from")
            destination = scope.get("to")

            if scope_type not in {"for", "route", "route_for"}:
                self._add_error(errors, "SCOPE_TYPE_INVALID", "$.scope.type", "Tipo de escopo não reconhecido.")

            if scope_type == "for" and not targets:
                self._add_error(errors, "TARGET_REQUIRED", "$.scope.targets", "O escopo for exige pelo menos um alvo.")

            if scope_type in {"route", "route_for"}:
                for name, value in (("from", origin), ("to", destination)):
                    if not isinstance(value, dict) or value.get("kind") != "endpoint" or not self._is_nonempty_string(value.get("value")):
                        self._add_error(errors, "ROUTE_ENDPOINT_INVALID", f"$.scope.{name}", f"O campo {name} deve ser um endpoint não vazio.")

            if scope_type == "route" and targets:
                self._add_error(errors, "ROUTE_TARGETS_UNEXPECTED", "$.scope.targets", "O escopo route não deve conter alvos adicionais.")

            for index, target in enumerate(targets):
                path = f"$.scope.targets[{index}]"
                if not isinstance(target, dict):
                    self._add_error(errors, "TARGET_INVALID", path, "O alvo deve ser um objeto estruturado.")
                    continue
                if target.get("kind") not in self.ALLOWED_TARGET_KINDS:
                    self._add_error(errors, "TARGET_KIND_INVALID", f"{path}.kind", "Tipo de alvo fora do subconjunto CAMPI.")
                if not self._is_nonempty_string(target.get("value")):
                    self._add_error(errors, "TARGET_VALUE_EMPTY", f"{path}.value", "O valor do alvo está vazio.")

        operations = ast.get("operations")
        if not isinstance(operations, list) or not operations:
            self._add_error(errors, "OPERATION_REQUIRED", "$.operations", "A intenção exige pelo menos uma operação.")
        else:
            for op_index, operation in enumerate(operations):
                op_path = f"$.operations[{op_index}]"
                if not isinstance(operation, dict):
                    self._add_error(errors, "OPERATION_INVALID", op_path, "A operação deve ser um objeto estruturado.")
                    continue

                operator = operation.get("operator")
                items = operation.get("items")

                if operator not in self.ALLOWED_OPERATORS:
                    self._add_error(errors, "OPERATOR_INVALID", f"{op_path}.operator", "Operador fora do subconjunto CAMPI.")

                if not isinstance(items, list) or not items:
                    self._add_error(errors, "OPERATION_ITEMS_REQUIRED", f"{op_path}.items", "A operação exige pelo menos um item.")
                    continue

                for item_index, item in enumerate(items):
                    item_path = f"{op_path}.items[{item_index}]"
                    if not isinstance(item, dict):
                        self._add_error(errors, "ITEM_INVALID", item_path, "O item deve ser um objeto estruturado.")
                        continue

                    kind = item.get("kind")

                    if operator == "add":
                        if kind != "middlebox":
                            self._add_error(errors, "ADD_KIND_INVALID", f"{item_path}.kind", "A operação add aceita apenas middlebox.")
                        if not self._is_nonempty_string(item.get("value")):
                            self._add_error(errors, "MIDDLEBOX_VALUE_EMPTY", f"{item_path}.value", "O middlebox não pode ser vazio.")

                    elif operator in {"allow", "block"}:
                        if kind not in self.ALLOWED_MATCH_KINDS:
                            self._add_error(errors, "MATCH_KIND_INVALID", f"{item_path}.kind", "allow/block aceitam service, traffic ou protocol.")
                        if not self._is_nonempty_string(item.get("value")):
                            self._add_error(errors, "MATCH_VALUE_EMPTY", f"{item_path}.value", "O item de allow/block não pode ser vazio.")

                    elif operator == "set":
                        constraint = item.get("constraint")
                        value = item.get("value")
                        unit = item.get("unit")

                        if kind == "quota":
                            if constraint not in self.QUOTA_CONSTRAINTS:
                                self._add_error(errors, "QUOTA_CONSTRAINT_INVALID", f"{item_path}.constraint", "Restrição de quota inválida.")
                            if unit not in self.QUOTA_UNITS:
                                self._add_error(errors, "QUOTA_UNIT_INVALID", f"{item_path}.unit", "Unidade de quota inválida para o subconjunto CAMPI.")
                        elif kind == "bandwidth":
                            if constraint not in self.BANDWIDTH_CONSTRAINTS:
                                self._add_error(errors, "BANDWIDTH_CONSTRAINT_INVALID", f"{item_path}.constraint", "Restrição de bandwidth inválida.")
                            if unit not in self.BANDWIDTH_UNITS:
                                self._add_error(errors, "BANDWIDTH_UNIT_INVALID", f"{item_path}.unit", "Unidade de bandwidth inválida para o subconjunto CAMPI.")
                        else:
                            self._add_error(errors, "SET_KIND_INVALID", f"{item_path}.kind", "A operação set aceita apenas quota ou bandwidth.")

                        if not self._is_number_string(value):
                            self._add_error(errors, "POLICY_VALUE_INVALID", f"{item_path}.value", "O valor da política deve ser numérico e não negativo.")

                    elif operator == "unset":
                        if kind != "bandwidth":
                            self._add_error(errors, "UNSET_KIND_INVALID", f"{item_path}.kind", "A operação unset aceita apenas bandwidth() no subconjunto CAMPI.")
                        unexpected = sorted(set(item) - {"kind"})
                        if unexpected:
                            self._add_error(errors, "UNSET_ARGUMENTS_UNEXPECTED", item_path, "A operação unset não recebe argumentos no subconjunto adotado.")

        interval = ast.get("interval")
        if interval is not None:
            if not isinstance(interval, dict):
                self._add_error(errors, "INTERVAL_INVALID", "$.interval", "O intervalo deve ser um objeto estruturado.")
            else:
                for name in ("start", "end"):
                    ref = interval.get(name)
                    path = f"$.interval.{name}"
                    if not isinstance(ref, dict) or ref.get("kind") != "hour":
                        self._add_error(errors, "INTERVAL_KIND_INVALID", path, "O subconjunto CAMPI aceita intervalos do tipo hour.")
                    elif not self._valid_hour(ref.get("value")):
                        self._add_error(errors, "HOUR_INVALID", f"{path}.value", "A hora deve seguir HH:MM entre 00:00 e 23:59.")

        return {
            "structural_valid": len(errors) == 0,
            "structural_errors": errors,
        }

    def validate(self, text: str) -> Dict[str, Any]:
        parsed = self.parse(text)
        if not parsed["syntax_valid"]:
            return {
                **parsed,
                "structural_valid": False,
                "structural_errors": [],
                "valid": False,
                "canonical_nile": None,
                "feedback": self.format_feedback(parsed["syntax_errors"], []),
            }

        structural = self.validate_ast(parsed["ast"])
        canonical_nile = render_ast(parsed["ast"])
        valid = parsed["syntax_valid"] and structural["structural_valid"]

        return {
            **parsed,
            **structural,
            "valid": valid,
            "canonical_nile": canonical_nile,
            "feedback": self.format_feedback(parsed["syntax_errors"], structural["structural_errors"]),
        }

    @staticmethod
    def format_feedback(syntax_errors: Iterable[Dict[str, Any]], structural_errors: Iterable[Dict[str, Any]]) -> str:
        syntax_errors = list(syntax_errors)
        structural_errors = list(structural_errors)

        if not syntax_errors and not structural_errors:
            return "Expressão Nile válida."

        lines = []
        for error in syntax_errors:
            location = ""
            if error.get("line") is not None and error.get("column") is not None:
                location = f" na linha {error['line']}, coluna {error['column']}"
            lines.append(f"ERRO SINTÁTICO{location}: {error.get('message', '')}")
            if error.get("context"):
                lines.append(f"Contexto: {error['context']}")

        for error in structural_errors:
            lines.append(f"ERRO ESTRUTURAL [{error.get('code')} em {error.get('path')}]: {error.get('message')}")

        return "\n".join(lines)


def _quote(value: str) -> str:
    if "'" in value:
        raise ValueError("O subconjunto adotado não permite apóstrofo dentro de valores Nile.")
    return f"'{value}'"


def _render_ref(item: Dict[str, Any]) -> str:
    return f"{item['kind']}({_quote(item['value'])})"


def render_ast(ast: Dict[str, Any]) -> str:
    if not isinstance(ast, dict):
        raise TypeError("A AST deve ser um dicionário.")

    parts = [f"define intent {ast['intent_id']}:"]
    scope = ast["scope"]

    if scope["type"] in {"route", "route_for"}:
        parts.append(f"from {_render_ref(scope['from'])}")
        parts.append(f"to {_render_ref(scope['to'])}")

    if scope["type"] in {"for", "route_for"}:
        targets = ", ".join(_render_ref(item) for item in scope["targets"])
        parts.append(f"for {targets}")

    for operation in ast["operations"]:
        operator = operation["operator"]
        rendered_items = []

        for item in operation["items"]:
            if operator in {"add", "allow", "block"}:
                rendered_items.append(_render_ref(item))
            elif operator == "set":
                rendered_items.append(
                    f"{item['kind']}({_quote(item['constraint'])}, {_quote(item['value'])}, {_quote(item['unit'])})"
                )
            elif operator == "unset":
                rendered_items.append(f"{item['kind']}()")
            else:
                raise ValueError(f"Operador não reconhecido: {operator}")

        parts.append(f"{operator} {', '.join(rendered_items)}")

    interval = ast.get("interval")
    if interval is not None:
        parts.append(f"start hour({_quote(interval['start']['value'])})")
        parts.append(f"end hour({_quote(interval['end']['value'])})")

    return " ".join(parts)


def structural_family(ast: Dict[str, Any]) -> str:
    families = set()
    for operation in ast.get("operations", []):
        operator = operation.get("operator")
        if operator == "add":
            families.add("middlebox")
        elif operator in {"allow", "block"}:
            families.add("acl")
        elif operator in {"set", "unset"}:
            families.add("qos")

    if len(families) > 1:
        return "mixed"
    if families:
        return next(iter(families))
    return "unknown"


def ast_complexity(ast: Dict[str, Any]) -> Dict[str, int]:
    scope = ast.get("scope", {})
    operations = ast.get("operations", [])
    n_targets = len(scope.get("targets", []) or [])
    n_items = sum(len(op.get("items", []) or []) for op in operations)
    has_route = int(scope.get("type") in {"route", "route_for"})
    has_temporal = int(ast.get("interval") is not None)
    score = n_targets + n_items + len(operations) + has_route + has_temporal
    return {
        "n_targets": n_targets,
        "n_operations": len(operations),
        "n_items": n_items,
        "has_route": has_route,
        "has_temporal": has_temporal,
        "complexity_score": score,
    }
