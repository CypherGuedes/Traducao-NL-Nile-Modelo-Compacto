from __future__ import annotations

import copy
from collections import Counter
from typing import Any, Dict, List, Tuple


def normalize_nile_text(text: Any) -> str:
    '''Padroniza somente espaços externos aos valores entre aspas simples.'''
    if text is None:
        return ""

    texto = str(text)
    resultado: List[str] = []
    espaco_pendente = False
    dentro_string = False

    for caractere in texto.strip():
        if caractere == "'":
            if not dentro_string and espaco_pendente:
                if resultado and resultado[-1] not in " (":
                    resultado.append(" ")
                espaco_pendente = False

            resultado.append(caractere)
            dentro_string = not dentro_string
            continue

        if dentro_string:
            resultado.append(caractere)
            continue

        if caractere.isspace():
            espaco_pendente = True
            continue

        if caractere == "(":
            while resultado and resultado[-1] == " ":
                resultado.pop()
            resultado.append(caractere)
            espaco_pendente = False
            continue

        if caractere == ")":
            while resultado and resultado[-1] == " ":
                resultado.pop()
            resultado.append(caractere)
            espaco_pendente = False
            continue

        if caractere == ",":
            while resultado and resultado[-1] == " ":
                resultado.pop()
            resultado.append(caractere)
            espaco_pendente = True
            continue

        if espaco_pendente and resultado and resultado[-1] not in " (":
            resultado.append(" ")

        espaco_pendente = False
        resultado.append(caractere)

    return "".join(resultado).strip()


def levenshtein_distance(reference: Any, prediction: Any) -> int:
    a = normalize_nile_text(reference)
    b = normalize_nile_text(prediction)

    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)

    previous = list(range(len(b) + 1))
    for i, char_a in enumerate(a, start=1):
        current = [i]
        for j, char_b in enumerate(b, start=1):
            insertion = current[j - 1] + 1
            deletion = previous[j] + 1
            substitution = previous[j - 1] + (char_a != char_b)
            current.append(min(insertion, deletion, substitution))
        previous = current
    return previous[-1]


def exact_match(reference: Any, prediction: Any) -> int:
    return int(normalize_nile_text(reference) == normalize_nile_text(prediction))


def normalized_edit_distance(reference: Any, prediction: Any) -> float:
    a = normalize_nile_text(reference)
    b = normalize_nile_text(prediction)
    denominator = max(len(a), len(b), 1)
    return levenshtein_distance(a, b) / denominator


def _freeze(value: Any) -> Any:
    if isinstance(value, dict):
        return tuple((key, _freeze(value[key])) for key in sorted(value))
    if isinstance(value, list):
        return tuple(_freeze(item) for item in value)
    return value


def _sort_key(item: Dict[str, Any]) -> Tuple[str, str, str, str]:
    return (
        str(item.get("kind", "")),
        str(item.get("constraint", "")),
        str(item.get("value", "")),
        str(item.get("unit", "")),
    )


def normalized_ast(ast: Dict[str, Any], ignore_intent_id: bool = True) -> Dict[str, Any]:
    '''Normaliza apenas listas cuja ordem não altera a intenção representada.'''
    if not isinstance(ast, dict):
        return {}

    scope_original = ast.get("scope") or {}
    scope = {
        "type": scope_original.get("type"),
        "from": copy.deepcopy(scope_original.get("from")),
        "to": copy.deepcopy(scope_original.get("to")),
        "targets": sorted(
            copy.deepcopy(scope_original.get("targets") or []),
            key=_sort_key,
        ),
    }

    operations = []
    for operation in ast.get("operations") or []:
        if not isinstance(operation, dict):
            continue

        operator = operation.get("operator")
        items = copy.deepcopy(operation.get("items") or [])

        if operator in {"allow", "block", "set", "unset"}:
            items = sorted(items, key=_sort_key)
        # Em add, a ordem dos middleboxes é preservada.

        operations.append({"operator": operator, "items": items})

    result = {
        "scope": scope,
        "operations": operations,
        "interval": copy.deepcopy(ast.get("interval")),
    }

    if not ignore_intent_id:
        result["intent_id"] = ast.get("intent_id")

    return result


def structural_exact(reference_ast: Dict[str, Any], prediction_ast: Dict[str, Any]) -> int:
    if not isinstance(reference_ast, dict) or not isinstance(prediction_ast, dict):
        return 0

    return int(
        _freeze(normalized_ast(reference_ast, ignore_intent_id=True))
        == _freeze(normalized_ast(prediction_ast, ignore_intent_id=True))
    )


def ast_atomic_fields(ast: Dict[str, Any]) -> List[Tuple[str, Any]]:
    '''Extrai campos atômicos e preserva ordem somente quando ela é semântica.'''
    if not isinstance(ast, dict):
        return []

    normalized = normalized_ast(ast, ignore_intent_id=True)
    fields: List[Tuple[str, Any]] = []

    scope = normalized.get("scope") or {}
    fields.append(("scope.type", scope.get("type")))

    source = scope.get("from")
    if isinstance(source, dict):
        fields.append(("scope.source.kind", source.get("kind")))
        fields.append(("scope.source.value", source.get("value")))

    destination = scope.get("to")
    if isinstance(destination, dict):
        fields.append(("scope.destination.kind", destination.get("kind")))
        fields.append(("scope.destination.value", destination.get("value")))

    for target in scope.get("targets") or []:
        if isinstance(target, dict):
            fields.append(("scope.target.kind", target.get("kind")))
            fields.append(("scope.target.value", target.get("value")))

    for op_index, operation in enumerate(normalized.get("operations") or []):
        if not isinstance(operation, dict):
            continue

        operator = operation.get("operator")
        op_prefix = f"operations[{op_index}]"
        fields.append((f"{op_prefix}.operator", operator))

        for item_index, item in enumerate(operation.get("items") or []):
            if not isinstance(item, dict):
                continue

            kind = item.get("kind")

            if operator == "add":
                # A posição integra o caminho porque add pode representar uma cadeia.
                item_prefix = f"{op_prefix}.items[{item_index}]"
                fields.append((f"{item_prefix}.kind", kind))
                fields.append((f"{item_prefix}.value", item.get("value")))

            elif operator in {"allow", "block"}:
                # Sem índice: a ordem dos itens de ACL não altera a intenção.
                fields.append((f"{op_prefix}.items.kind", kind))
                fields.append((f"{op_prefix}.items.value", item.get("value")))

            elif operator == "set":
                # Políticas são avaliadas por campos atômicos e por tipo.
                policy_prefix = f"{op_prefix}.policies.{kind}"
                fields.append((f"{op_prefix}.policies.kind", kind))
                fields.append((f"{policy_prefix}.constraint", item.get("constraint")))
                fields.append((f"{policy_prefix}.value", item.get("value")))
                fields.append((f"{policy_prefix}.unit", item.get("unit")))

            elif operator == "unset":
                fields.append((f"{op_prefix}.policies.kind", kind))

    interval = normalized.get("interval")
    if isinstance(interval, dict):
        for name in ("start", "end"):
            ref = interval.get(name)
            if isinstance(ref, dict):
                fields.append((f"interval.{name}.kind", ref.get("kind")))
                fields.append((f"interval.{name}.value", ref.get("value")))

    return fields


def field_level_adherence(reference_ast: Dict[str, Any], prediction_ast: Dict[str, Any]) -> float:
    reference_fields = Counter(ast_atomic_fields(reference_ast))
    prediction_fields = Counter(ast_atomic_fields(prediction_ast))

    reference_total = sum(reference_fields.values())
    prediction_total = sum(prediction_fields.values())

    if reference_total == 0 and prediction_total == 0:
        return 1.0
    if reference_total == 0 or prediction_total == 0:
        return 0.0

    matches = sum((reference_fields & prediction_fields).values())
    denominator = max(reference_total, prediction_total)
    return matches / denominator if denominator else 1.0


def evaluate_pair(
    reference_nile: Any,
    prediction_nile: Any,
    validator,
) -> Dict[str, Any]:
    reference_text = normalize_nile_text(reference_nile)
    prediction_text = normalize_nile_text(prediction_nile)

    reference_validation = validator.validate(reference_text)
    prediction_validation = validator.validate(prediction_text)

    reference_ast = reference_validation.get("ast") if reference_validation.get("valid") else None
    prediction_ast = prediction_validation.get("ast") if prediction_validation.get("valid") else None

    return {
        "psr": int(prediction_validation.get("syntax_valid", False)),
        "structural_valid": int(prediction_validation.get("structural_valid", False)),
        "em": exact_match(reference_text, prediction_text),
        "ed": levenshtein_distance(reference_text, prediction_text),
        "ned": normalized_edit_distance(reference_text, prediction_text),
        "sla_s": structural_exact(reference_ast, prediction_ast),
        "sla_f": field_level_adherence(reference_ast, prediction_ast),
        "reference_valid": bool(reference_validation.get("valid", False)),
        "prediction_valid": bool(prediction_validation.get("valid", False)),
        "prediction_feedback": prediction_validation.get("feedback", ""),
    }
