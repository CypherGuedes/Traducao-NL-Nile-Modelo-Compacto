from __future__ import annotations

import re
from typing import Any, Dict, List


MIN_LENGTH = 40
MAX_LENGTH = 900

ENGLISH_SIGNALS = {
    "the", "a", "an", "and", "or", "of", "as", "on", "in", "by", "this",
    "that", "which", "to", "from", "for", "with", "without", "is", "are",
    "maps", "mapped", "represents", "represented", "identifies", "identified",
    "renders", "rendered", "translates", "translated", "statement", "intent",
    "expression", "field", "fields", "scope", "operation", "target",
    "source", "destination", "constraint", "becomes", "become", "yield",
    "yields", "produces", "produced", "captures", "captured",
}

PORTUGUESE_SIGNALS = {
    "frase", "intenção", "intencao", "escopo", "operação", "operacao",
    "operações", "operacoes", "aplicada", "aplicado", "sobre", "sem",
    "restrição", "restricao", "entrada", "justificativa", "representa",
    "identifica", "traduz", "tradução", "traducao", "expressão", "expressao",
    "estrutura", "configura", "configurado", "adiciona", "bloqueia", "permite",
    "para", "pela", "pelo", "dos", "das",
}

FORBIDDEN_PATTERNS = [
    r"as an ai language model",
    r"as a language model",
    r"i cannot",
    r"i can't",
    r"como modelo de linguagem",
    r"não posso",
    r"nao posso",
    r"não tenho acesso",
    r"nao tenho acesso",
    r"chain[ -]?of[ -]?thought",
    r"racioc[ií]nio interno",
    r"system instructions",
    r"instru[cç][õo]es do sistema",
    r"original prompt",
    r"prompt original",
]

OPERATOR_FORMS = {
    "add": (
        "add", "adds", "added", "adding", "insert", "inserts", "inserted",
        "introduce", "introduces", "introduced", "deploy", "deploys", "deployed",
    ),
    "allow": (
        "allow", "allows", "allowed", "allowing", "permit", "permits",
        "permitted", "permitting",
    ),
    "block": (
        "block", "blocks", "blocked", "blocking", "prohibit", "prohibits",
        "prohibited", "prevent", "prevents", "prevented", "deny", "denies",
        "denied",
    ),
    "set": (
        "set", "sets", "setting", "configure", "configures", "configured",
        "configuring", "assign", "assigns", "assigned", "limit", "limits",
        "limited", "cap", "caps", "capped",
    ),
    "unset": (
        "unset", "unsets", "unsetting", "remove", "removes", "removed",
        "removing", "no bandwidth limit", "without bandwidth limit",
        "no rate limit", "without rate limits",
    ),
}

R1_CUES = (
    "ir", "intermediate representation", "map", "maps", "mapped", "mapping",
    "represent", "represents", "represented", "capture", "captures", "captured",
    "scope", "operation", "target",
)

R2_CUES = (
    "nile", "render", "renders", "rendered", "translate", "translates",
    "translated", "composition", "compose", "composes", "construct",
    "constructs", "constructed", "become", "becomes", "yield", "yields",
    "produce", "produces", "generate", "generates", "definition",
    "starts with", "followed by",
)

R2_FORMAL_TERMS = (
    "intent_id", "intent", "scope", "source", "destination", "target",
    "targets", "endpoint", "group", "operation", "operator", "add", "allow",
    "block", "set", "unset", "quota", "bandwidth", "middlebox", "protocol",
    "service", "traffic", "temporal constraint", "start", "end", "for",
    "from", "to",
)

R3_CUES = (
    "nl", "natural language", "intent", "map", "maps", "mapped", "translate",
    "translates", "translated", "express", "expressed", "represent",
    "represented", "capture", "captured", "model", "modeled", "realize",
    "realized", "implement", "implemented", "correspond", "corresponding",
    "reflect", "reflecting", "directly",
)

FORMAL_CALL_PATTERN = re.compile(
    r"\b(?:endpoint|group|middlebox|protocol|service|traffic|quota|bandwidth|hour)"
    r"\s*\(([^()]*)\)",
    flags=re.IGNORECASE,
)


def normalize_text(text: Any) -> str:
    return re.sub(r"\s+", " ", str(text)).strip()


def _normalized(text: Any) -> str:
    return normalize_text(text).casefold()


def _mentions(text: str, value: Any) -> bool:
    value_text = normalize_text(value)
    if not value_text:
        return False

    text_norm = _normalized(text)
    value_norm = value_text.casefold()

    if re.fullmatch(r"[A-Za-z0-9_\-]+", value_text):
        return re.search(
            r"(?<![A-Za-z0-9_])" + re.escape(value_norm) + r"(?![A-Za-z0-9_])",
            text_norm,
        ) is not None

    return value_norm in text_norm


def _mentions_any(text: str, values) -> bool:
    return any(_mentions(text, value) for value in values)


def _scope_values(ir: Dict[str, Any]) -> List[str]:
    scope = ir["scope"]
    values = []

    source = scope.get("source")
    destination = scope.get("destination")

    if isinstance(source, dict) and source.get("value"):
        values.append(str(source["value"]))
    if isinstance(destination, dict) and destination.get("value"):
        values.append(str(destination["value"]))

    for target in scope.get("targets", []):
        if target.get("value"):
            values.append(str(target["value"]))

    return values


def _temporal_values(ir: Dict[str, Any]) -> List[str]:
    temporal = ir.get("temporal_constraint")
    if not isinstance(temporal, dict):
        return []
    return [str(temporal["start"]), str(temporal["end"])]


def _formal_literals(text: str) -> List[str]:
    values = []
    for arguments in FORMAL_CALL_PATTERN.findall(str(text)):
        values.extend(
            normalize_text(item)
            for item in re.findall(r"'([^']*)'", arguments)
        )
    return values


def _allowed_formal_literals(record: Dict[str, Any]) -> set[str]:
    ir = record["ir"]
    allowed = set()

    scope = ir["scope"]
    for endpoint in (scope.get("source"), scope.get("destination")):
        if isinstance(endpoint, dict):
            for field in ("kind", "value"):
                if endpoint.get(field) not in (None, ""):
                    allowed.add(_normalized(endpoint[field]))

    for target in scope.get("targets", []):
        for field in ("kind", "value"):
            if target.get(field) not in (None, ""):
                allowed.add(_normalized(target[field]))

    for operation in ir.get("operations", []):
        if operation.get("operator"):
            allowed.add(_normalized(operation["operator"]))
        for item in operation.get("items", []):
            for field in ("kind", "constraint", "value", "unit"):
                if item.get(field) not in (None, ""):
                    allowed.add(_normalized(item[field]))

    for value in _temporal_values(ir):
        allowed.add(_normalized(value))

    return allowed


def _operator_mentioned(text: str, operator: str) -> bool:
    forms = OPERATOR_FORMS.get(operator, (operator,))
    return _mentions_any(text, forms)


def _semantic_item_mentioned(text: str, item: Dict[str, Any]) -> bool:
    kind = str(item.get("kind", ""))
    value = item.get("value")

    if kind == "traffic" and str(value).casefold() == "any":
        return _mentions(text, "any") or _mentions(text, "all traffic")

    anchor = value if value not in (None, "") else kind
    return _mentions(text, anchor)


def _rationale_role_mentioned(rationale_type: str, text: str) -> bool:
    if rationale_type == "R1":
        return _mentions_any(text, R1_CUES)

    if rationale_type == "R2":
        if _mentions_any(text, R2_CUES):
            return True
        formal_hits = sum(_mentions(text, term) for term in R2_FORMAL_TERMS)
        return formal_hits >= 2

    return _mentions_any(text, R3_CUES)


def validate_common(text: Any) -> Dict[str, Any]:
    errors = []
    warnings = []

    if not isinstance(text, str):
        return {
            "approved": False,
            "errors": ["A justificativa deve ser uma string."],
            "warnings": [],
            "characters": 0,
        }

    clean = normalize_text(text)
    length = len(clean)

    if not clean:
        errors.append("A justificativa está vazia.")
    if length < MIN_LENGTH:
        errors.append(f"A justificativa possui menos de {MIN_LENGTH} caracteres.")
    if length > MAX_LENGTH:
        errors.append(f"A justificativa possui mais de {MAX_LENGTH} caracteres.")
    if "```" in text:
        errors.append("A justificativa contém bloco de código Markdown.")
    if clean.startswith("{") or clean.startswith("["):
        errors.append("A justificativa contém estrutura JSON no campo textual.")

    clean_norm = clean.casefold()
    for pattern in FORBIDDEN_PATTERNS:
        if re.search(pattern, clean_norm, flags=re.IGNORECASE):
            errors.append("A justificativa contém resposta metalinguística ou raciocínio oculto.")
            break

    tokens = set(re.findall(r"[A-Za-zÀ-ÖØ-öø-ÿ_]+", clean_norm))
    english_hits = tokens.intersection(ENGLISH_SIGNALS)
    portuguese_hits = tokens.intersection(PORTUGUESE_SIGNALS)
    possui_acento_portugues = bool(re.search(r"[áàâãéêíóôõúç]", clean_norm))

    if len(english_hits) < 2:
        errors.append("A justificativa não contém evidência suficiente de prosa em inglês.")
    if possui_acento_portugues or len(portuguese_hits) >= 2:
        errors.append("A justificativa deve ser escrita integralmente em inglês.")

    if length > 650:
        warnings.append("A justificativa é longa para uso como artefato demonstrativo.")

    return {
        "approved": not errors,
        "errors": errors,
        "warnings": warnings,
        "characters": length,
    }


def _validate_grounding(
    rationale_type: str,
    record: Dict[str, Any],
    text: str,
) -> Dict[str, Any]:
    errors = []
    warnings = []
    ir = record["ir"]

    expected_anchors = []
    matched_anchors = []

    def register(anchor: str, matched: bool, error_message: str) -> None:
        expected_anchors.append(anchor)
        if matched:
            matched_anchors.append(anchor)
        else:
            errors.append(error_message)

    for operation in ir.get("operations", []):
        operator = str(operation.get("operator", ""))
        register(
            f"operator:{operator}",
            _operator_mentioned(text, operator),
            f"O operator '{operator}' não foi representado na justificativa.",
        )

    for value in _scope_values(ir):
        register(
            f"scope:{value}",
            _mentions(text, value),
            f"O elemento de scope '{value}' não foi mencionado.",
        )

    scope_type = ir["scope"]["type"]
    if scope_type in {"route", "route_for"}:
        direction_ok = (
            _mentions_any(text, ("from", "source", "origin"))
            and _mentions_any(text, ("to", "destination"))
        )
        register(
            "scope:route_direction",
            direction_ok,
            "A direção source/from para destination/to não foi representada.",
        )

    for operation_index, operation in enumerate(ir.get("operations", [])):
        for item_index, item in enumerate(operation.get("items", [])):
            kind = str(item.get("kind", ""))

            if rationale_type == "R2":
                register(
                    f"operation:{operation_index}:item:{item_index}:kind:{kind}",
                    _mentions(text, kind),
                    f"O kind '{kind}' da operation não foi mencionado em R2.",
                )

                for field in ("constraint", "value", "unit"):
                    value = item.get(field)
                    if value in (None, ""):
                        continue
                    register(
                        f"operation:{operation_index}:item:{item_index}:{field}:{value}",
                        _mentions(text, value),
                        f"O campo '{field}' com valor '{value}' não foi mencionado em R2.",
                    )
            else:
                anchor = item.get("value") or item.get("kind")
                register(
                    f"operation:{operation_index}:item:{item_index}:{anchor}",
                    _semantic_item_mentioned(text, item),
                    f"O item '{anchor}' da operation não foi representado.",
                )

    for value in _temporal_values(ir):
        register(
            f"temporal:{value}",
            _mentions(text, value),
            f"O valor temporal '{value}' não foi mencionado.",
        )

    register(
        f"role:{rationale_type}",
        _rationale_role_mentioned(rationale_type, text),
        f"A justificativa não apresenta sinais suficientes do papel de {rationale_type}.",
    )

    allowed_literals = _allowed_formal_literals(record)
    unsupported_literals = [
        value
        for value in _formal_literals(text)
        if _normalized(value) not in allowed_literals
    ]
    if unsupported_literals:
        errors.append(
            "Foram encontrados valores formais não sustentados pelo exemplo: "
            + ", ".join(unsupported_literals)
        )

    unique_expected = list(dict.fromkeys(expected_anchors))
    unique_matched = list(dict.fromkeys(matched_anchors))
    coverage = (
        len(unique_matched) / len(unique_expected)
        if unique_expected
        else 1.0
    )

    if coverage < 0.75:
        warnings.append("A cobertura das âncoras verificáveis ficou abaixo de 75%.")

    return {
        "approved": not errors,
        "errors": errors,
        "warnings": warnings,
        "expected_anchors": unique_expected,
        "matched_anchors": unique_matched,
        "anchor_coverage": coverage,
    }


def validate_rationale(
    rationale_type: str,
    record: Dict[str, Any],
    text: Any,
) -> Dict[str, Any]:
    rationale_type = str(rationale_type).upper()
    if rationale_type not in {"R1", "R2", "R3"}:
        raise ValueError(f"Tipo de justificativa inválido: {rationale_type}")

    common = validate_common(text)
    clean = normalize_text(text)

    grounding = _validate_grounding(rationale_type, record, clean) if clean else {
        "approved": False,
        "errors": [],
        "warnings": [],
        "expected_anchors": [],
        "matched_anchors": [],
        "anchor_coverage": 0.0,
    }

    errors = common["errors"] + grounding["errors"]
    warnings = common["warnings"] + grounding["warnings"]

    return {
        "approved": len(errors) == 0,
        "normalized_text": clean,
        "errors": errors,
        "warnings": warnings,
        "characters": common["characters"],
        "expected_anchors": grounding["expected_anchors"],
        "matched_anchors": grounding["matched_anchors"],
        "anchor_coverage": grounding["anchor_coverage"],
    }

