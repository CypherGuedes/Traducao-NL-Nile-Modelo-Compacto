from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import os
import random
import re
import sys
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(str(text).encode("utf-8"))


def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    path = Path(path)
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: str | Path) -> Any:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(data: Any, path: str | Path, *, indent: int = 2) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=indent)
        handle.write("\n")


def read_jsonl(path: str | Path) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                record = json.loads(stripped)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"JSONL inválido em {path}, linha {line_number}: {exc}"
                ) from exc
            if not isinstance(record, dict):
                raise TypeError(
                    f"Registro JSONL em {path}, linha {line_number}, não é um objeto."
                )
            records.append(record)
    return records


def write_jsonl(records: Iterable[Mapping[str, Any]], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(
                json.dumps(dict(record), ensure_ascii=False, separators=(",", ":"))
            )
            handle.write("\n")


def extract_zip(zip_path: str | Path, output_dir: str | Path, *, clean: bool = True) -> Path:
    zip_path = Path(zip_path)
    output_dir = Path(output_dir)
    if clean and output_dir.exists():
        import shutil
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as package:
        package.extractall(output_dir)
    return output_dir


def import_module_from_path(module_name: str, path: str | Path):
    path = Path(path)
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Não foi possível criar o módulo {module_name} a partir de {path}.")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def canonical_json(data: Any) -> str:
    return json.dumps(
        data,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def stable_seed(base_seed: int, *parts: Any) -> int:
    payload = "|".join([str(base_seed), *[str(part) for part in parts]])
    return int(hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16], 16) % (2**32)


def fill_template(template: str, values: Mapping[str, Any]) -> str:
    result = str(template)
    for key, value in values.items():
        result = result.replace("{{" + str(key) + "}}", str(value))
    unresolved = sorted(set(re.findall(r"\{\{([A-Z0-9_]+)\}\}", result)))
    if unresolved:
        raise ValueError(
            "Placeholders não preenchidos: " + ", ".join(unresolved)
        )
    return result.strip() + "\n"


def strip_code_fences(text: Any) -> str:
    value = "" if text is None else str(text).strip()
    value = re.sub(r"^\s*```(?:json|text|nile)?\s*", "", value, flags=re.I)
    value = re.sub(r"\s*```\s*$", "", value)
    return value.strip()


def extract_balanced_json(text: Any) -> Tuple[Optional[Dict[str, Any]], str, Optional[str]]:
    cleaned = strip_code_fences(text)
    starts = [idx for idx, char in enumerate(cleaned) if char == "{"]
    for start in starts:
        depth = 0
        in_string = False
        escape = False
        for index in range(start, len(cleaned)):
            char = cleaned[index]
            if in_string:
                if escape:
                    escape = False
                elif char == "\\":
                    escape = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    candidate = cleaned[start:index + 1]
                    try:
                        parsed = json.loads(candidate)
                    except json.JSONDecodeError:
                        break
                    if isinstance(parsed, dict):
                        return parsed, candidate, None
                    return None, candidate, "O JSON extraído não é um objeto."
    return None, "", "Nenhum objeto JSON balanceado e válido foi encontrado."


def extract_nile(text: Any, validator: Any = None) -> Dict[str, Any]:
    raw = "" if text is None else str(text)
    cleaned = strip_code_fences(raw)
    cleaned = cleaned.replace("\r\n", "\n").replace("\r", "\n").strip()

    start_positions = [m.start() for m in re.finditer(r"(?i)\bdefine\s+intent\b", cleaned)]
    candidates: List[str] = []

    for start in start_positions:
        remainder = cleaned[start:].strip()
        candidates.append(remainder)
        lines = [line.strip() for line in remainder.splitlines() if line.strip()]
        if lines:
            candidates.append(lines[0])
            for end in range(len(lines), 0, -1):
                candidates.append(" ".join(lines[:end]).strip())

    if not candidates and cleaned:
        candidates.append(cleaned)

    unique_candidates: List[str] = []
    seen = set()
    for candidate in candidates:
        candidate = re.sub(r"\s+", " ", candidate).strip()
        candidate = re.sub(r"^(?:Nile|Saída Nile|Output)\s*:\s*", "", candidate, flags=re.I)
        if candidate and candidate not in seen:
            seen.add(candidate)
            unique_candidates.append(candidate)

    if validator is not None:
        for candidate in unique_candidates:
            result = validator.validate(candidate)
            if result.get("syntax_valid", False):
                return {
                    "nile": candidate,
                    "extraction_valid": True,
                    "extraction_method": "first_syntax_valid_candidate",
                    "validation": result,
                }

    fallback = unique_candidates[0] if unique_candidates else ""
    validation = validator.validate(fallback) if validator is not None else None
    return {
        "nile": fallback,
        "extraction_valid": bool(fallback),
        "extraction_method": "first_candidate_fallback" if fallback else "empty",
        "validation": validation,
    }


def format_demo_a(record: Mapping[str, Any], index: int) -> str:
    return (
        f"Exemplo {index}:\n"
        f"Entrada em linguagem natural:\n{record['nl']}\n"
        f"Saída Nile:\n{record['nile']}"
    )


def format_demo_c_ir(record: Mapping[str, Any], index: int) -> str:
    return (
        f"Exemplo {index}:\n"
        f"Entrada em linguagem natural:\n{record['nl']}\n"
        f"Representação Intermediária:\n{canonical_json(record['ir'])}"
    )


def format_demo_c_ir_nile(record: Mapping[str, Any], index: int) -> str:
    return (
        f"Exemplo {index}:\n"
        f"Representação Intermediária:\n{canonical_json(record['ir'])}\n"
        f"Saída Nile:\n{record['nile']}"
    )


def format_demo_d_r3(record: Mapping[str, Any], index: int) -> str:
    return (
        f"Exemplo {index}:\n"
        f"Entrada em linguagem natural:\n{record['nl']}\n"
        f"R3:\n{record['r3']}\n"
        f"Saída Nile:\n{record['nile']}"
    )


def format_demo_e_r1(record: Mapping[str, Any], index: int) -> str:
    return (
        f"Exemplo {index}:\n"
        f"Entrada em linguagem natural:\n{record['nl']}\n"
        f"R1:\n{record['r1']}\n"
        f"Representação Intermediária:\n{canonical_json(record['ir'])}"
    )


def format_demo_e_r2(record: Mapping[str, Any], index: int) -> str:
    return (
        f"Exemplo {index}:\n"
        f"Representação Intermediária:\n{canonical_json(record['ir'])}\n"
        f"R2:\n{record['r2']}\n"
        f"Saída Nile:\n{record['nile']}"
    )


DEMO_FORMATTERS = {
    "A": format_demo_a,
    "C_IR": format_demo_c_ir,
    "C_IR_NILE": format_demo_c_ir_nile,
    "D_R3": format_demo_d_r3,
    "E_R1": format_demo_e_r1,
    "E_R2": format_demo_e_r2,
}


def build_demos(
    selected_ids: Sequence[str],
    records_by_id: Mapping[str, Mapping[str, Any]],
    format_key: str,
) -> str:
    if not selected_ids:
        return "Nenhum exemplo demonstrativo."
    if format_key not in DEMO_FORMATTERS:
        raise KeyError(f"Formato de demonstração desconhecido: {format_key}")
    formatter = DEMO_FORMATTERS[format_key]
    parts = []
    for index, item_id in enumerate(selected_ids, start=1):
        if item_id not in records_by_id:
            raise KeyError(f"ID demonstrativo ausente: {item_id}")
        parts.append(formatter(records_by_id[item_id], index))
    return "\n\n".join(parts)


def build_prompt_a(template: str, nl_test: str, demos: str) -> str:
    return fill_template(template, {
        "EXEMPLOS_FEW_SHOT": demos,
        "NL_TESTE": nl_test,
    })


def build_prompt_c_ir(template: str, nl_test: str, demos: str, ir_schema: Mapping[str, Any]) -> str:
    return fill_template(template, {
        "IR_SCHEMA_JSON": json.dumps(ir_schema, ensure_ascii=False, indent=2),
        "EXEMPLOS_FEW_SHOT_IR": demos,
        "NL_TESTE": nl_test,
    })


def build_prompt_c_nile(template: str, ir_test: Mapping[str, Any] | str, demos: str) -> str:
    ir_text = ir_test if isinstance(ir_test, str) else canonical_json(ir_test)
    return fill_template(template, {
        "EXEMPLOS_FEW_SHOT_IR_NILE": demos,
        "IR_TESTE": ir_text,
    })


def build_prompt_d(template: str, nl_test: str, demos: str) -> str:
    return fill_template(template, {
        "EXEMPLOS_FEW_SHOT_R3": demos,
        "NL_TESTE": nl_test,
    })


def build_prompt_e_ir(template: str, nl_test: str, demos: str, ir_schema: Mapping[str, Any]) -> str:
    return fill_template(template, {
        "IR_SCHEMA_JSON": json.dumps(ir_schema, ensure_ascii=False, indent=2),
        "EXEMPLOS_FEW_SHOT_R1": demos,
        "NL_TESTE": nl_test,
    })


def build_prompt_e_nile(template: str, ir_test: Mapping[str, Any] | str, demos: str) -> str:
    ir_text = ir_test if isinstance(ir_test, str) else canonical_json(ir_test)
    return fill_template(template, {
        "EXEMPLOS_FEW_SHOT_R2": demos,
        "IR_TESTE": ir_text,
    })


def build_prompt_autocorrection(
    template: str,
    nl_test: str,
    auxiliary_artifacts: str,
    rejected_nile: str,
    validator_feedback: str,
    demos: str,
) -> str:
    return fill_template(template, {
        "NL_TESTE": nl_test,
        "ARTEFATOS_AUXILIARES": auxiliary_artifacts or "Nenhum.",
        "NILE_REJEITADA": rejected_nile,
        "FEEDBACK_VALIDACAO_NILE": validator_feedback,
        "EXEMPLOS_FEW_SHOT": demos,
    })


def load_selection_map(path: str | Path) -> Dict[Tuple[int, str, str, int], Dict[str, Any]]:
    records = read_jsonl(path)
    mapping: Dict[Tuple[int, str, str, int], Dict[str, Any]] = {}
    for record in records:
        key = (
            int(record["fold"]),
            str(record["test_id"]),
            str(record["selection_method"]),
            int(record["k"]),
        )
        if key in mapping:
            raise ValueError(f"Seleção duplicada para {key}.")
        mapping[key] = record
    return mapping


def get_selected_ids(
    selection_map: Mapping[Tuple[int, str, str, int], Mapping[str, Any]],
    fold: int,
    test_id: str,
    selection_method: str,
    k: int,
) -> List[str]:
    if int(k) == 0:
        return []
    key = (int(fold), str(test_id), str(selection_method), int(k))
    if key not in selection_map:
        raise KeyError(f"Seleção não encontrada: {key}")
    return list(selection_map[key]["selected_ids"])


def resolve_local_model_dir(root: str | Path, name_hints: Sequence[str]) -> Optional[Path]:
    root = Path(root)
    if not root.exists():
        return None
    hints = [hint.lower().replace("_", "-") for hint in name_hints]
    candidates = []
    for config_path in root.rglob("config.json"):
        parent = config_path.parent
        normalized = str(parent).lower().replace("_", "-")
        if all(hint in normalized for hint in hints):
            candidates.append(parent)
    if not candidates:
        return None
    candidates.sort(key=lambda path: (len(path.parts), str(path)))
    return candidates[0]


def load_student_model(
    model_source: str | Path,
    *,
    use_cuda: bool = True,
    local_files_only: bool = False,
):
    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError as exc:
        raise ImportError(
            "Instale transformers e accelerate antes de carregar o modelo aluno."
        ) from exc

    source = str(model_source)
    cuda_available = bool(use_cuda and torch.cuda.is_available())
    dtype = torch.float16 if cuda_available else torch.float32

    tokenizer = AutoTokenizer.from_pretrained(
        source,
        use_fast=True,
        local_files_only=local_files_only,
        trust_remote_code=False,
    )
    model = AutoModelForCausalLM.from_pretrained(
        source,
        torch_dtype=dtype,
        device_map="auto" if cuda_available else None,
        low_cpu_mem_usage=True,
        local_files_only=local_files_only,
        trust_remote_code=False,
    )
    if not cuda_available:
        model.to("cpu")
    model.eval()

    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id

    return tokenizer, model


def generate_student_output(
    prompt: str,
    tokenizer: Any,
    model: Any,
    *,
    max_new_tokens: int,
    seed: int = 42,
) -> Dict[str, Any]:
    import torch
    try:
        from transformers import set_seed
        set_seed(seed)
    except Exception:
        random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

    messages = [{"role": "user", "content": prompt}]
    encoded = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=True,
        return_dict=True,
        return_tensors="pt",
    )
    model_device = next(model.parameters()).device
    encoded = {key: value.to(model_device) for key, value in encoded.items()}
    prompt_tokens = int(encoded["input_ids"].shape[-1])

    start = time.perf_counter()
    with torch.inference_mode():
        generated = model.generate(
            **encoded,
            do_sample=False,
            max_new_tokens=int(max_new_tokens),
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
            use_cache=True,
        )
    elapsed = time.perf_counter() - start

    new_ids = generated[0, prompt_tokens:]
    text = tokenizer.decode(new_ids, skip_special_tokens=True).strip()

    return {
        "response_raw": text,
        "prompt_tokens": prompt_tokens,
        "generated_tokens": int(new_ids.shape[-1]),
        "elapsed_seconds": float(elapsed),
        "finish_reason": "eos_or_limit",
    }


def validate_generated_ir(text: Any, ir_schema: Mapping[str, Any], ir_core_module: Any) -> Dict[str, Any]:
    parsed, extracted, extraction_error = extract_balanced_json(text)
    if parsed is None:
        return {
            "ir": None,
            "ir_text": extracted,
            "ir_valid": False,
            "ir_errors": [extraction_error or "Falha de extração da IR."],
        }
    result = ir_core_module.validate_ir(parsed, dict(ir_schema))
    errors = [
        f"{item.get('path')}: {item.get('message')}"
        for item in result.get("schema_errors", [])
    ]
    return {
        "ir": parsed,
        "ir_text": extracted,
        "ir_valid": bool(result.get("schema_valid", False)),
        "ir_errors": errors,
    }


def evaluate_nile_output(
    reference_nile: str,
    response_text: Any,
    validator: Any,
    metrics_module: Any,
) -> Dict[str, Any]:
    extraction = extract_nile(response_text, validator=validator)
    predicted = extraction["nile"]
    metrics = metrics_module.evaluate_pair(reference_nile, predicted, validator)
    return {
        **extraction,
        **metrics,
        "validator_feedback": metrics.get("prediction_feedback", ""),
    }


def make_result_record(**kwargs: Any) -> Dict[str, Any]:
    defaults = {
        "phase": "F3",
        "strategy": None,
        "variant": None,
        "fold": None,
        "id": None,
        "k": None,
        "selection_method": None,
        "selection_label": None,
        "demonstration_ids": [],
        "demonstration_scores": [],
        "nl": None,
        "reference_nile": None,
        "prompt_primary": None,
        "response_primary_raw": None,
        "prompt_secondary": None,
        "response_secondary_raw": None,
        "prompt_autocorrection": None,
        "response_autocorrection_raw": None,
        "generated_ir": None,
        "generated_ir_text": None,
        "ir_valid": None,
        "ir_errors": [],
        "nile_initial": None,
        "nile_corrected": None,
        "nile_evaluated": None,
        "syntax_valid": None,
        "validator_feedback": None,
        "autocorrection_applied": False,
        "attempt": 1,
        "psr": None,
        "em": None,
        "ed": None,
        "ned": None,
        "sla_s": None,
        "sla_f": None,
        "prompt_primary_sha256": None,
        "prompt_secondary_sha256": None,
        "prompt_autocorrection_sha256": None,
        "prompt_primary_tokens": None,
        "prompt_secondary_tokens": None,
        "prompt_autocorrection_tokens": None,
        "generated_primary_tokens": None,
        "generated_secondary_tokens": None,
        "generated_autocorrection_tokens": None,
        "elapsed_primary_seconds": None,
        "elapsed_secondary_seconds": None,
        "elapsed_autocorrection_seconds": None,
        "status": "pending",
        "error": None,
    }
    unexpected = sorted(set(kwargs) - set(defaults))
    if unexpected:
        raise KeyError("Campos de resultado desconhecidos: " + ", ".join(unexpected))
    defaults.update(kwargs)
    hash_pairs = [
        ("prompt_primary", "prompt_primary_sha256"),
        ("prompt_secondary", "prompt_secondary_sha256"),
        ("prompt_autocorrection", "prompt_autocorrection_sha256"),
    ]
    for prompt_field, hash_field in hash_pairs:
        if defaults[prompt_field] is not None and defaults[hash_field] is None:
            defaults[hash_field] = sha256_text(defaults[prompt_field])
    return defaults
