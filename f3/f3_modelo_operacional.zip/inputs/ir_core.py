from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Dict, Iterable

from jsonschema import Draft202012Validator


IR_VERSION = "1.0.0"


def load_schema(path: str | Path) -> Dict[str, Any]:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Esquema da IR não encontrado: {path}")

    with path.open("r", encoding="utf-8") as file:
        schema = json.load(file)

    Draft202012Validator.check_schema(schema)
    return schema


def _format_path(parts: Iterable[Any]) -> str:
    path = "$"
    for part in parts:
        if isinstance(part, int):
            path += f"[{part}]"
        else:
            path += f".{part}"
    return path


def validate_ir(ir: Any, schema: Dict[str, Any]) -> Dict[str, Any]:
    validator = Draft202012Validator(schema)
    errors = []

    for error in sorted(
        validator.iter_errors(ir),
        key=lambda item: (tuple(str(part) for part in item.absolute_path), item.message),
    ):
        errors.append({
            "path": _format_path(error.absolute_path),
            "message": error.message,
            "validator": error.validator,
        })

    return {
        "schema_valid": len(errors) == 0,
        "schema_errors": errors,
    }


def assert_valid_ir(ir: Any, schema: Dict[str, Any]) -> None:
    result = validate_ir(ir, schema)
    if result["schema_valid"]:
        return

    details = "\n".join(
        f"- {error['path']}: {error['message']}"
        for error in result["schema_errors"]
    )
    raise ValueError("A IR não é válida segundo o esquema:\n" + details)


def ast_to_ir(ast: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(ast, dict):
        raise TypeError("A AST deve ser um dicionário.")

    scope = ast.get("scope")
    operations = ast.get("operations")

    if not isinstance(scope, dict):
        raise ValueError("A AST não contém um scope válido.")
    if not isinstance(operations, list):
        raise ValueError("A AST não contém uma lista de operations.")

    interval = ast.get("interval")

    ir = {
        "intent_id": ast.get("intent_id"),
        "scope": {
            "type": scope.get("type"),
            "source": copy.deepcopy(scope.get("from")),
            "destination": copy.deepcopy(scope.get("to")),
            "targets": copy.deepcopy(scope.get("targets") or []),
        },
        "operations": copy.deepcopy(operations),
        "temporal_constraint": None,
    }

    if interval is not None:
        ir["temporal_constraint"] = {
            "start": interval["start"]["value"],
            "end": interval["end"]["value"],
        }

    return ir


def ir_to_ast(ir: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(ir, dict):
        raise TypeError("A IR deve ser um dicionário.")

    scope = ir.get("scope")
    operations = ir.get("operations")

    if not isinstance(scope, dict):
        raise ValueError("A IR não contém um scope válido.")
    if not isinstance(operations, list):
        raise ValueError("A IR não contém uma lista de operations.")

    temporal = ir.get("temporal_constraint")

    ast = {
        "intent_id": ir.get("intent_id"),
        "scope": {
            "type": scope.get("type"),
            "from": copy.deepcopy(scope.get("source")),
            "to": copy.deepcopy(scope.get("destination")),
            "targets": copy.deepcopy(scope.get("targets") or []),
        },
        "operations": copy.deepcopy(operations),
        "interval": None,
    }

    if temporal is not None:
        ast["interval"] = {
            "start": {"kind": "hour", "value": temporal["start"]},
            "end": {"kind": "hour", "value": temporal["end"]},
        }

    return ast


def canonical_ir_json(ir: Dict[str, Any]) -> str:
    return json.dumps(
        ir,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def summarize_ir(ir: Dict[str, Any]) -> Dict[str, Any]:
    scope = ir["scope"]
    source = scope.get("source")
    destination = scope.get("destination")
    operations = ir["operations"]

    return {
        "intent_id": ir["intent_id"],
        "scope_type": scope["type"],
        "source": None if source is None else source.get("value"),
        "destination": None if destination is None else destination.get("value"),
        "targets": ", ".join(
            f"{item['kind']}('{item['value']}')"
            for item in scope.get("targets", [])
        ),
        "n_targets": len(scope.get("targets", [])),
        "n_operations": len(operations),
        "operators": " | ".join(op["operator"] for op in operations),
        "n_items": sum(len(op.get("items", [])) for op in operations),
        "has_temporal": ir.get("temporal_constraint") is not None,
    }
